import django.core.validators
import tasty_recipes_app.web.validators
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = []

    operations = []
